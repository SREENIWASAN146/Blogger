const express = require("express");
const mongoose = require("mongoose");
const app = express();
const ejs = require("ejs");
const sessions = require("express-session");
const PosT = require("./postdb");
const Profile = require("./profiledb");
const multer = require("multer");

let imagename;

// --- MongoDB Connection ---
mongoose.set("strictQuery", false);
mongoose.connect("mongodb://localhost:27017/blog", { useNewUrlParser: true })
  .then(() => console.log("MongoDB connected"))
  .catch(err => console.log(err));

// --- Middleware ---
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.set("view engine", "ejs");
app.use(express.static("public"));
app.use(sessions({
  secret: "secret key",
  saveUninitialized: true,
  resave: false,
}));

// --- File Upload ---
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, "./public/thumbnails"),
  filename: (req, file, cb) => {
    imagename = file.originalname;
    cb(null, file.originalname);
  }
});
const upload = multer({ storage: storage });

// --- Visits Schema ---
const visitSchema = new mongoose.Schema({ visits: Number });
const visits = mongoose.model("visits", visitSchema);

// --- Home Page ---
app.get("/", (req, res) => res.render("login"));

app.get("/home", async (req, res) => {
  if (!req.session.useremail) return res.redirect("/");
  try {
    const posts = await PosT.find().exec();
    const sortedPosts = await PosT.find().sort({ like: -1 }).exec();
    res.render("home", {
      user: req.session.username,
      posts: posts,
      sposts: sortedPosts,
      date: Date.now()
    });
  } catch (err) {
    console.log(err);
    res.status(500).send("Error fetching posts");
  }
});

// --- Logout ---
app.get("/logout", (req, res) => {
  req.session.destroy(err => {
    if (err) console.log(err);
    imagename = null;
    res.redirect("/");
  });
});

// --- Signup ---
app.get("/signup", (req, res) => res.redirect("/"));

app.post("/signup", async (req, res) => {
  const userExists = await Profile.exists({ username: req.body.name });
  if (userExists) return res.send("<script>alert('User already exists');window.location.href='/'</script>");

  await Profile.insertMany({
    username: req.body.name,
    email: req.body.email,
    password: req.body.password,
    type: "user",
    fullname: req.body.name,
    dp: "", bio: "", weblink: "",
    facebook: "", whatsapp: "", twitter: "", instagram: "", phoneno: ""
  });

  req.session.useremail = req.body.email;
  req.session.username = req.body.name;
  res.redirect("/home");
});

// --- Login ---
app.post("/login", async (req, res) => {
  try {
    const check = await Profile.findOne({ email: req.body.email });
    if (!check || check.password !== req.body.password) {
      return res.send("<script>alert('Wrong details');window.location.href='/'</script>");
    }

    req.session.useremail = check.email;
    req.session.username = check.username;
    req.session.type = check.type;

    if (check.type === "admin") res.redirect("/admin");
    else {
      await visits.findOneAndUpdate({ _id: "640cb99cd1ab2ecb248598b4" }, { $inc: { visits: 1 } });
      res.redirect("/home");
    }
  } catch {
    res.send("<script>alert('Error logging in');window.location.href='/'</script>");
  }
});

// --- Compose Post ---
app.get("/compose", (req, res) => {
  if (!req.session.username) return res.redirect("/");
  res.render("compose", { user: req.session.username });
});

app.post("/compose", upload.single("image"), async (req, res) => {
  await PosT.insertMany({
    author: req.session.username,
    title: req.body.postTitle,
    content: req.body.postBody,
    thumbnail: imagename,
    date: Date.now(),
    like: 0
  });
  res.redirect("/home");
});

// --- Profile Page ---
app.get("/profile/:customRoute", (req, res) => {
  if (!req.session.username) return res.redirect("/");

  const customRoute = req.params.customRoute;
  PosT.find({ author: customRoute }, (err, posts) => {
    if (err) return res.status(500).send("Error fetching posts");

    Profile.findOne({ username: customRoute }, (err, userdata) => {
      if (err || !userdata) return res.status(404).send("Profile not found");

      res.render("profile", {
        username: req.session.username,
        posts: posts,
        userdata: userdata,
        date: Date.now()
      });
    });
  });
});

// --- Edit Profile ---
app.get("/editprofile/:custom", (req, res) => {
  if (!req.session.username) return res.redirect("/");
  Profile.findOne({ username: req.params.custom }, (err, userdata) => {
    if (!userdata || req.session.username !== userdata.username) return res.status(404).send("Not found");
    res.render("edit-profile", { username: req.session.username, email: req.session.useremail, userdata });
  });
});

app.post("/editprofile/:custom", upload.single("image"), async (req, res) => {
  const custom = req.params.custom;
  await Profile.findOneAndUpdate(
    { username: req.session.username },
    {
      fullname: req.body.fullname,
      dp: imagename,
      bio: req.body.bio,
      weblink: req.body.weblink,
      facebook: req.body.fb,
      whatsapp: req.body.wa,
      twitter: req.body.tw,
      instagram: req.body.insta,
      phoneno: req.body.phno
    }
  );
  res.redirect("/profile/" + custom);
});

// --- Admin Dashboard ---
app.get("/admin", async (req, res) => {
  if (req.session.type !== "admin") return res.redirect("/");
  const profiles = await Profile.find();
  const posts = await PosT.find();
  const visitData = await visits.find();
  res.render("admin", { profiles, posts, visits: visitData, username: req.session.username });
});

// --- Catch-all 404 (LAST) ---
app.get("*", (req, res) => res.status(404).send("Page not found"));

// --- Start Server ---
app.listen(process.env.PORT || 3000, () => console.log("Server started at port 3000"));
